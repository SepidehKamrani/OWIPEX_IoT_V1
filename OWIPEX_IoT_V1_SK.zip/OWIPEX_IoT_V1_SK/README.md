# Owipex_Project

IoT System Refactoring for Water Treatment Monitoring


